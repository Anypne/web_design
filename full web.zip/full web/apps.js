const textarea = document.getElementById("textarea1");

function execCommandWithArg(command, arg) {
    document.execCommand(command, false, arg);
}

function f1() {
    let value = window.getSelection().toString();
    if (value !== "") {
        execCommandWithArg("fontSize", "5"); // Example: You can set any font size you want.
    }
}

function f2() {
    execCommandWithArg("bold", null);
}

function f3() {
    execCommandWithArg("italic", null);
}

function f4() {
    execCommandWithArg("underline", null);
}

function f5() {
    execCommandWithArg("justifyLeft", null);
}

function f6() {
    execCommandWithArg("justifyCenter", null);
}

function f7() {
    execCommandWithArg("justifyRight", null);
}

function f8() {
    execCommandWithArg("uppercase", null);
}

function f9() {
    textarea.innerHTML = "";
}

function f10(e) {
    let value = e.value;
    execCommandWithArg("foreColor", value);
}

window.addEventListener('load', () => {
    textarea.value = "";
});